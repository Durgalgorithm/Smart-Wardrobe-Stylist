
import React from 'react';
import { AvatarState, WardrobeItem, Category } from '../types';

interface Props {
  avatar: AvatarState;
  selectedItems: WardrobeItem[];
}

const AvatarCanvas: React.FC<Props> = ({ avatar, selectedItems }) => {
  // Optimal visual layering for fashion
  const layerOrder = [
    Category.SHOES,
    Category.BOTTOMS,
    Category.TOPS,
    Category.OUTERWEAR,
    Category.ACCESSORIES // Accessories stay on top
  ];

  const sortedItems = [...selectedItems].sort((a, b) => 
    layerOrder.indexOf(a.category) - layerOrder.indexOf(b.category)
  );

  return (
    <div className="relative w-full max-w-lg aspect-[3/4] bg-white rounded-2xl shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] overflow-hidden border-8 border-white ring-1 ring-slate-100">
      {/* Base Human Template */}
      <img 
        src={avatar.imageUrl} 
        alt="Avatar" 
        className="absolute inset-0 w-full h-full object-cover"
      />
      
      {/* Dynamic Clothing Overlays (Simulated Fit) */}
      <div className="absolute inset-0 pointer-events-none">
        {sortedItems.map((item, idx) => {
          let styles: React.CSSProperties = {
            position: 'absolute',
            opacity: 1.0,
            transition: 'all 0.4s cubic-bezier(0.19, 1, 0.22, 1)',
            filter: 'drop-shadow(0 8px 15px rgba(0,0,0,0.2))',
            zIndex: idx + 10,
          };

          // Accurate positioning relative to 3:4 aspect ratio human body template
          switch(item.category) {
            case Category.TOPS:
              styles = { ...styles, top: '20%', left: '22%', width: '56%', height: '36%' };
              break;
            case Category.BOTTOMS:
              styles = { ...styles, top: '44%', left: '26%', width: '48%', height: '44%' };
              break;
            case Category.SHOES:
              styles = { ...styles, bottom: '4%', left: '32%', width: '36%', height: '15%' };
              break;
            case Category.OUTERWEAR:
              styles = { ...styles, top: '18%', left: '16%', width: '68%', height: '46%' };
              break;
            case Category.ACCESSORIES:
              styles = { ...styles, top: '5%', left: '30%', width: '40%', height: '22%' };
              break;
          }

          return (
            <img 
              key={item.id}
              src={item.imageUrl}
              alt={item.name}
              style={styles}
              className="object-contain animate-in zoom-in-95 fade-in duration-500"
            />
          );
        })}
      </div>

      {/* Guide UI when empty */}
      {selectedItems.length === 0 && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-indigo-900/5 backdrop-blur-[2px]">
          <div className="bg-white/95 px-10 py-8 rounded-[2.5rem] shadow-2xl text-center border border-slate-50 transform translate-y-20 animate-in slide-in-from-bottom-12 duration-1000">
            <div className="bg-indigo-600 text-white w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl shadow-indigo-100">
               <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4zm2 5V6a2 2 0 10-4 0v1h4zm-6 3a1 1 0 112 0 1 1 0 01-2 0zm7-1a1 1 0 100 2 1 1 0 000-2z" clipRule="evenodd" />
              </svg>
            </div>
            <p className="text-slate-900 font-black uppercase tracking-[0.2em] text-[10px]">Mirror Ready</p>
            <p className="text-[10px] text-slate-400 font-bold mt-2 uppercase">Your identity is locked. Select clothes to try on.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default AvatarCanvas;

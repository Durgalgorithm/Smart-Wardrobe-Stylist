
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { WardrobeItem } from '../types';
import { connectLiveStylist, createPcmBlob, decodeAudioData, encode } from '../services/live-api';

interface Props {
  wardrobeItems: WardrobeItem[];
}

const VoiceAssistant: React.FC<Props> = ({ wardrobeItems }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transcript, setTranscript] = useState<{ text: string, isUser: boolean }[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const outputCtxRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const wardrobeContext = wardrobeItems.map(i => `${i.name} (${i.category})`).join(', ');

  const stopSession = useCallback(() => {
    setIsActive(false);
    setIsConnecting(false);
    
    if (sessionRef.current) {
      // Logic for closing session if available
    }

    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }

    if (audioCtxRef.current) {
      audioCtxRef.current.close();
      audioCtxRef.current = null;
    }

    if (outputCtxRef.current) {
      outputCtxRef.current.close();
      outputCtxRef.current = null;
    }

    activeSourcesRef.current.forEach(source => source.stop());
    activeSourcesRef.current.clear();
    nextStartTimeRef.current = 0;
  }, []);

  const startSession = async () => {
    try {
      setIsConnecting(true);
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioCtxRef.current = inputCtx;
      outputCtxRef.current = outputCtx;

      const session = await connectLiveStylist({
        onAudioData: async (audioBuffer) => {
          setIsSpeaking(true);
          const source = outputCtx.createBufferSource();
          source.buffer = audioBuffer;
          source.connect(outputCtx.destination);
          
          const startTime = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
          source.start(startTime);
          
          nextStartTimeRef.current = startTime + audioBuffer.duration;
          activeSourcesRef.current.add(source);
          source.onended = () => {
            activeSourcesRef.current.delete(source);
            if (activeSourcesRef.current.size === 0) setIsSpeaking(false);
          };
        },
        onInterrupted: () => {
          activeSourcesRef.current.forEach(s => s.stop());
          activeSourcesRef.current.clear();
          nextStartTimeRef.current = 0;
          setIsSpeaking(false);
        },
        onTranscription: (text, isUser) => {
          setTranscript(prev => [...prev.slice(-10), { text, isUser }]);
        },
        onError: (err) => {
          console.error("Live API Error:", err);
          stopSession();
        },
        onClose: () => {
          console.log("Live API Closed");
          stopSession();
        }
      }, wardrobeContext);

      sessionRef.current = session;

      // Microphone streaming logic
      const source = inputCtx.createMediaStreamSource(stream);
      const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
      scriptProcessor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        const pcmBlob = createPcmBlob(inputData);
        session.sendRealtimeInput({ media: pcmBlob });
      };
      source.connect(scriptProcessor);
      scriptProcessor.connect(inputCtx.destination);

      setIsActive(true);
      setIsConnecting(false);
    } catch (err) {
      console.error("Failed to start session:", err);
      setIsConnecting(false);
    }
  };

  const toggleAssistant = () => {
    if (isActive) stopSession();
    else startSession();
  };

  return (
    <div className="flex flex-col items-end gap-4">
      {isActive && (
        <div className="w-80 bg-white rounded-2xl shadow-2xl p-4 border border-slate-200 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-2">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-bold text-slate-700">Stylist Online</span>
            </div>
            <button onClick={stopSession} className="text-slate-400 hover:text-slate-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>

          <div className="h-48 overflow-y-auto mb-4 space-y-3 pr-2 custom-scrollbar">
            {transcript.length === 0 && (
              <p className="text-xs text-slate-400 text-center py-8 italic">"Ask me about your wardrobe or what to wear for dinner!"</p>
            )}
            {transcript.map((t, idx) => (
              <div key={idx} className={`flex ${t.isUser ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-xs ${
                  t.isUser ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'
                }`}>
                  {t.text}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-center">
            <div className="flex gap-1 items-center">
              {[1, 2, 3, 4, 5].map(i => (
                <div 
                  key={i} 
                  className={`w-1 bg-indigo-500 rounded-full transition-all duration-300 ${
                    isSpeaking ? 'h-6 animate-bounce' : 'h-2'
                  }`} 
                  style={{ animationDelay: `${i * 0.1}s` }}
                ></div>
              ))}
            </div>
          </div>
        </div>
      )}

      <button
        onClick={toggleAssistant}
        disabled={isConnecting}
        className={`w-16 h-16 rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-95 ${
          isActive 
            ? 'bg-red-500 hover:bg-red-600 text-white' 
            : 'bg-indigo-600 hover:bg-indigo-700 text-white hover:scale-105'
        }`}
      >
        {isConnecting ? (
          <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        ) : isActive ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
            <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
            <line x1="12" x2="12" y1="19" y2="22"></line>
          </svg>
        )}
      </button>
    </div>
  );
};

export default VoiceAssistant;

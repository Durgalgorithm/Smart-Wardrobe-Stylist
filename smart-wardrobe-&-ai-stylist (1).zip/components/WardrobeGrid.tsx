
import React from 'react';
import { WardrobeItem } from '../types';

interface Props {
  items: WardrobeItem[];
  onToggle: (id: string) => void;
  onRemove: (id: string) => void;
}

const WardrobeGrid: React.FC<Props> = ({ items, onToggle, onRemove }) => {
  if (items.length === 0) {
    return (
      <div className="text-center py-12 border-2 border-dashed border-slate-100 rounded-xl">
        <p className="text-slate-400 text-sm">No items added yet.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-3">
      {items.map((item) => (
        <div 
          key={item.id} 
          className={`relative group rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
            item.isSelected ? 'border-indigo-500 ring-2 ring-indigo-200' : 'border-transparent'
          }`}
          onClick={() => onToggle(item.id)}
        >
          <img 
            src={item.imageUrl} 
            alt={item.name} 
            className="w-full h-32 object-cover bg-slate-50"
          />
          <div className="p-2 bg-white flex justify-between items-center">
            <span className="text-xs font-medium text-slate-700 truncate">{item.name}</span>
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onRemove(item.id);
              }}
              className="text-slate-300 hover:text-red-500 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
          {item.isSelected && (
            <div className="absolute top-2 right-2 bg-indigo-500 text-white rounded-full p-1 shadow-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default WardrobeGrid;

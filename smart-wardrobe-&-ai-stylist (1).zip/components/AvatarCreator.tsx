
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";

interface Props {
  onAvatarGenerated: (imageUrl: string) => void;
  onClose: () => void;
}

const AvatarCreator: React.FC<Props> = ({ onAvatarGenerated, onClose }) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generateAvatar = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setError(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      // We use a specific system instruction to ensure the avatar is suitable for a dressing room
      // Updated to ask for a NEUTRAL BASE LAYER to prevent clothing artifacts
      const finalPrompt = `A high-quality, professional 3D digital avatar character for a fashion app. 
      Full body shot, standing in a neutral T-pose or relaxed neutral pose against a solid light grey studio background. 
      The character must be wearing a simple, skin-tight, neutral gray base layer (like a bodysuit or minimal gym gear).
      This allows other digital clothes to be overlaid perfectly.
      Subject appearance: ${prompt}. 
      High resolution, sharp focus, professional fashion lighting.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: finalPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: "3:4"
          }
        },
      });

      const imagePart = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
      if (imagePart?.inlineData) {
        const imageUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`;
        onAvatarGenerated(imageUrl);
        onClose();
      } else {
        throw new Error("No image was generated. Please try a different description.");
      }
    } catch (err: any) {
      console.error("Avatar Gen Error:", err);
      setError(err.message || "Failed to generate avatar. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
        <div className="p-8">
          <div className="flex justify-between items-start mb-6">
            <div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight">AI Avatar Creator</h3>
              <p className="text-sm text-slate-500 mt-1">Describe your look to create your digital twin.</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3">Appearance Details</label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g., A woman with long wavy red hair, green eyes, friendly smile, athletic build..."
                className="w-full h-32 p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-indigo-500 focus:outline-none transition-all resize-none text-slate-700 text-sm"
              />
            </div>

            {error && (
              <div className="p-4 bg-red-50 text-red-600 text-xs rounded-xl border border-red-100 font-medium">
                {error}
              </div>
            )}

            <button
              onClick={generateAvatar}
              disabled={isGenerating || !prompt.trim()}
              className={`w-full py-4 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all ${
                isGenerating || !prompt.trim()
                  ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xl shadow-indigo-100 active:scale-95'
              }`}
            >
              {isGenerating ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Styling your twin...</span>
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M5 2a1 1 0 011 1v1h1a1 1 0 010 2H6v1a1 1 0 01-2 0V6H3a1 1 0 010-2h1V3a1 1 0 011-1zm12 1a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0V6h-1a1 1 0 110-2h1V4a1 1 0 011-1zm-3 7a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0v-1h-1a1 1 0 110-2h1v-1a1 1 0 011-1zm-8 4a1 1 0 011 1v1h1a1 1 0 110 2H7v1a1 1 0 11-2 0v-1H4a1 1 0 110-2h1v-1a1 1 0 011-1z" clipRule="evenodd" />
                    <path d="M11 3a1 1 0 011 1v12a1 1 0 11-2 0V4a1 1 0 011-1z" />
                  </svg>
                  <span>Generate Avatar</span>
                </>
              )}
            </button>
            <p className="text-[10px] text-center text-slate-400 font-medium italic">Gemini creates your stable identity template.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AvatarCreator;


import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

// Audio constants
const INPUT_SAMPLE_RATE = 16000;
const OUTPUT_SAMPLE_RATE = 24000;

export function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

export function createPcmBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: `audio/pcm;rate=${INPUT_SAMPLE_RATE}`,
  };
}

export interface LiveSessionHandlers {
  onAudioData: (buffer: AudioBuffer) => void;
  onInterrupted: () => void;
  onTranscription: (text: string, isUser: boolean) => void;
  onError: (error: any) => void;
  onClose: () => void;
}

export async function connectLiveStylist(handlers: LiveSessionHandlers, wardrobeContext: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const sessionPromise = ai.live.connect({
    model: 'gemini-2.5-flash-native-audio-preview-12-2025',
    config: {
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
      },
      systemInstruction: `You are a professional fashion stylist. Help the user plan outfits from their wardrobe. 
      The user's current wardrobe includes: ${wardrobeContext}. 
      Give advice on colors, styles, and combinations. Be friendly and fashion-forward.`,
      outputAudioTranscription: {},
      inputAudioTranscription: {},
    },
    callbacks: {
      onopen: () => console.log('Live session connected'),
      onmessage: async (message: LiveServerMessage) => {
        if (message.serverContent?.outputTranscription) {
          handlers.onTranscription(message.serverContent.outputTranscription.text, false);
        } else if (message.serverContent?.inputTranscription) {
          handlers.onTranscription(message.serverContent.inputTranscription.text, true);
        }

        const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
        if (audioData) {
          const tempCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: OUTPUT_SAMPLE_RATE });
          const decoded = await decodeAudioData(decode(audioData), tempCtx, OUTPUT_SAMPLE_RATE, 1);
          handlers.onAudioData(decoded);
          await tempCtx.close();
        }

        if (message.serverContent?.interrupted) {
          handlers.onInterrupted();
        }
      },
      onerror: (e) => handlers.onError(e),
      onclose: () => handlers.onClose(),
    },
  });

  return sessionPromise;
}
